"use client";

import Scene from "./scene";

export default function Home() {
  return (
    <>
    <Scene />
    <h1 className="text-3xl">Hey</h1>
    </>
  );
}
